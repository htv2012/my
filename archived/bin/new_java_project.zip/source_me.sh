function run() {
    if gradle build
    then
        local main_class=$(basename $PWD)

        echo ========================================
        echo java $main_class
        echo ========================================

        pushd build/classes/java/main > /dev/null
        java $main_class
        popd > /dev/null
    fi
}

function clean() {
    rm -fr build
}


echo Commands are: run and clean
